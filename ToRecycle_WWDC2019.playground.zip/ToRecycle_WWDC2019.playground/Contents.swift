// Hello!
// This playground is made to work in portrait orientation.
//
// Our planet is our home, we need to take care of it.
// Have fun!
//
//
//Special thanks to the music owner (public domain): https://creativecommons.org/publicdomain/zero/1.0/
//

import PlaygroundSupport
import GameplayKit

let view = SKView(frame: CGRect(x:0 , y:0, width: 640, height: 480))

if let scene = GameScene(fileNamed: "GameScene") {
    scene.scaleMode = .aspectFill
    
    view.presentScene(scene)
}

PlaygroundSupport.PlaygroundPage.current.liveView = view
