//
//  Sprite.swift
//  WWDC2019
//
//  Created by Giovanni Bruno on 19/03/19.
//  Copyright © 2019 Giovanni Bruno. All rights reserved.
//

import Foundation
import GameplayKit

class Sprite: GKComponent {
    
    let node: SKNode
    
    init(node: SKNode) {
        self.node = node
        super.init()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError()
    }
    
}
