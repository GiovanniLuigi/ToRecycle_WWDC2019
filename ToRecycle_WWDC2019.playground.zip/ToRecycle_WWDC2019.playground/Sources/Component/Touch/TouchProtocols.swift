//
//  ScreenTouch.swift
//  WWDC2019
//
//  Created by Giovanni Bruno on 23/03/19.
//  Copyright © 2019 Giovanni Bruno. All rights reserved.
//

import GameplayKit


protocol TouchHandler {
    func touchesBegan(_ point: CGPoint)
    func touchesEnded(_ point: CGPoint)
    func touchesMoved(_ point: CGPoint)
}

extension TouchHandler {
    func touchesBegan(_ point: CGPoint) {}
    func touchesEnded(_ point: CGPoint) {}
    func touchesMoved(_ point: CGPoint) {}
}
