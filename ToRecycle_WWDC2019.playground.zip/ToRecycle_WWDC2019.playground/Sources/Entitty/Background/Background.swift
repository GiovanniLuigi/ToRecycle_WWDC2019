//
//  Background.swift
//  WWDC2019
//
//  Created by Giovanni Bruno on 23/03/19.
//  Copyright © 2019 Giovanni Bruno. All rights reserved.
//

import GameplayKit

class Background: GKEntity {
    
    init(frame: CGRect) {
        super.init()
        
        // Sprite Component
        let node = SKSpriteNode(imageNamed: "background")
        let myFrameHeight = frame.height*20
        let myFrame = CGRect(x: -sceneSize.width/2, y: -sceneSize.height/2, width: frame.width, height: myFrameHeight)
        node.physicsBody = SKPhysicsBody(edgeLoopFrom: myFrame)
        node.physicsBody?.isDynamic = false
        node.physicsBody?.categoryBitMask = Physics.wall
        node.zPosition = -1
        
        let sprite = Sprite(node: node)
        addComponent(sprite)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("Not implemented")
    }
    
}
