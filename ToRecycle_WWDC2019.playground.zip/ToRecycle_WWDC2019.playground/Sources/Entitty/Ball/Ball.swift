//
//  Player.swift
//  WWDC2019
//
//  Created by Giovanni Bruno on 23/03/19.
//  Copyright © 2019 Giovanni Bruno. All rights reserved.
//

import GameplayKit

protocol BallDelegate {
    func didHitTheWall(_ ball: Ball)
}

class Ball: GKEntity, Contactable {
    
    private let simulationKey = "simulation"
    public var delegate: BallDelegate?
    public let type: WasteType
    
    public var node: SKSpriteNode? {
        return component(ofType: Sprite.self)?.node as? SKSpriteNode
    }
    
    public init(type: WasteType) {
        self.type = type
        super.init()
        
        // Sprite Component
        let ballNode = createBallNode(type: type)
        ballNode.name = "ball"
        let sprite = Sprite(node: ballNode)
        
        addComponent(sprite)
    }
    
    private func createBallNode(type: WasteType) -> SKSpriteNode {
        let node = SKSpriteNode(texture: type.textureForBall())
        node.zPosition = 1
        node.isUserInteractionEnabled = false
        node.position = CGPoint(x: -565, y: -600)
        node.physicsBody = SKPhysicsBody(circleOfRadius: node.size.width/2)
        node.physicsBody?.affectedByGravity = false
        node.physicsBody?.angularDamping = 0.35
        node.physicsBody?.friction = 0.75
        node.physicsBody?.restitution = 0
        
        node.physicsBody?.categoryBitMask = Physics.ball
        node.physicsBody?.contactTestBitMask = Physics.hoopLine | Physics.wall
        node.physicsBody?.collisionBitMask = Physics.wall
        
        return node
    }
    
    public func throwBall(touchPoint: CGPoint) {
        guard let ball = self.node else {return}
        ball.physicsBody?.affectedByGravity = true
        let distance = touchPoint - ball.position
        let strength = distance.length()/(1/(ball.physicsBody?.mass ?? 1)/1.75)
        let direction = distance.normalized().angle
        
        let impulse = SKAction.applyImpulse(CGVector(angle: direction)*strength, duration: 0.01)
        ball.run(impulse)
        ball.physicsBody?.applyTorque(-1)
    }
    
    func didBegin(_ contact: SKPhysicsContact) {
        let contactMask = contact.bodyA.categoryBitMask | contact.bodyB.categoryBitMask
        if contactMask == Physics.ball | Physics.wall {
            print("miss ball")
            delegate?.didHitTheWall(self)
            if let node = self.node {
                node.physicsBody?.contactTestBitMask = Physics.none
            }
        }
    }

    override func update(deltaTime seconds: TimeInterval) {
        super.update(deltaTime: seconds)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("Not implemented")
    }
    
}
