//
//  EntityManager.swift
//  WWDC2019
//
//  Created by Giovanni Bruno on 19/03/19.
//  Copyright © 2019 Giovanni Bruno. All rights reserved.
//

import Foundation
import GameplayKit


class EntityManager {
    
    let scene: GameScene
    var entities = Set<GKEntity>()
    var toRemove = Set<GKEntity>()
    lazy var systems: [GKComponentSystem] = {
        return []
    }()
    
    init(scene: GameScene) {
        self.scene = scene
        
    }
    
    func add(_ entity: GKEntity) {
        self.entities.insert(entity)
        
        for system in self.systems {
            system.addComponent(foundIn: entity)
        }
        
        if let sprite = entity.component(ofType: Sprite.self) {
            sprite.node.entity = entity
            self.scene.addChild(sprite.node)
        }
    }
    
    func remove(_ entity: GKEntity) {
        if let spriteNode = entity.component(ofType: Sprite.self)?.node {
            spriteNode.removeFromParent()
        }
        
        toRemove.insert(entity)
        entities.remove(entity)
    }
    
    func removeAll(ofType: GKEntity.Type) {
        for entity in self.entities {
            if type(of: entity) == ofType {
                self.remove(entity)
            }
        }
    }
    
    func findFirstEntity(ofType: GKEntity.Type) -> GKEntity? {
        return self.entities.first(where: { (entity) -> Bool in
            return type(of: entity) == ofType
        })
    }
    
    func findAllEntities(ofType: GKEntity.Type) -> Set<GKEntity> {
        return self.entities.filter({ (entity) -> Bool in
            return type(of: entity) == ofType
        })
    }
    
    func findAllEntities(withComponent ofType: GKComponent.Type) -> Set<GKEntity> {
        return self.entities.filter({ (entity) -> Bool in
            return entity.component(ofType: ofType) != nil
        })
    }
    
    
    func update(_ dt: TimeInterval) {
        for entity in toRemove {
            for system in systems {
                system.removeComponent(foundIn: entity)
            }
        }
        toRemove.removeAll()
        
        for system in systems {
            system.update(deltaTime: dt)
        }
        
        for entity in entities {
            entity.update(deltaTime: dt)
        }
        
    }
    
}

