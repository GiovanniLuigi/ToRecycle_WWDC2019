//
//  DialogManager.swift
//  WWDC2019
//
//  Created by Giovanni Bruno on 24/03/19.
//  Copyright © 2019 Giovanni Bruno. All rights reserved.
//

import GameplayKit

enum AvaiableLevel: Int {
    case introduction = 1, first, second, infinite
}

struct Level {
    let dialogs: [SKSpriteNode]
    
    static func create(avaiableLevel: AvaiableLevel) -> Level {
        switch avaiableLevel {
        case .introduction:
            return Level(dialogs: [
                dialogNode(imageNamed: "dialog1"),
                dialogNode(imageNamed: "dialog2")
                ])
        case .first:
            return Level(dialogs: [
                dialogNode(imageNamed: "dialog3"),
                dialogNode(imageNamed: "dialog4")
                ])
        case .second:
            return Level(dialogs: [
                dialogNode(imageNamed: "dialog5"),
                dialogNode(imageNamed: "dialog6")
                ])
        case .infinite:
            return Level(dialogs: [
                dialogNode(imageNamed: "dialog7"),
                dialogNode(imageNamed: "dialog8")
                ])

        }
    }
    
    private static func dialogNode(imageNamed: String) -> SKSpriteNode {
        let node = SKSpriteNode(imageNamed: imageNamed)
        node.setScale(0)
        node.position = CGPoint(x: 0, y: 700)
        return node
    }
}


class DialogManager {
    private static let allLevels: [Level] = [
        Level.create(avaiableLevel: .introduction),
        Level.create(avaiableLevel: .first),
        Level.create(avaiableLevel: .second),
        Level.create(avaiableLevel: .infinite)
    ]
    
    private let currentLevel: Int
    private let player: Player
    private let game: Game
    
    private var currentDialogIndex: Int = 0
    
    init(level: Int, player: Player, game: Game) {
        self.player = player
        self.game = game
        self.currentLevel = level
    }
    //returns false if it's over
    public func nextDialog() -> Bool {
        guard currentLevel < DialogManager.allLevels.count else {return false}
        let level = DialogManager.allLevels[currentLevel]
        if currentDialogIndex < level.dialogs.count {
            if currentDialogIndex-1 > -1 {
                hideDialog(currentDialogIndex-1) { [weak self] in
                    guard let self = self else {return}
                    self.showDialog(self.currentDialogIndex)
                    self.currentDialogIndex += 1
                }
            } else {
                self.showDialog(self.currentDialogIndex)
                self.currentDialogIndex += 1
            }
            return true
        } else {
            if currentDialogIndex-1 > -1 {
                hideDialog(currentDialogIndex-1) {}
            }
            return false
        }
    }
    
    private func hideDialog(_ index: Int, completion: @escaping () -> Void) {
        guard currentLevel < DialogManager.allLevels.count else {return}
        let level = DialogManager.allLevels[currentLevel]
        let dialogNode = level.dialogs[index]
        dialogNode.run(SKAction.scale(to: 0, duration: 0.35)) {
            dialogNode.removeFromParent()
            completion()
        }
    }
    
    private func showDialog(_ index: Int) {
        guard currentLevel < DialogManager.allLevels.count else {return}
        let level = DialogManager.allLevels[currentLevel]
        let dialogNode = level.dialogs[index]
        game.add(dialogNode)
        dialogNode.run(SKAction.scale(to: 1, duration: 0.25))
    }
}

