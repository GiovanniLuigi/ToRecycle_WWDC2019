//
//  Game.swift
//  WWDC2019
//
//  Created by Giovanni Bruno on 23/03/19.
//  Copyright © 2019 Giovanni Bruno. All rights reserved.
//

import GameplayKit

protocol GameDelegate {
    func ballDidHitTheWall(_ game: Game, ball: Ball)
    func didThrowBall(_ game: Game, player: Player)
    func didFallTheHoop(_ game: Game, ball: Ball, correctBasket: Bool)
    func shouldStart(_ game: Game, player: Player)
    func didTouchScreen(_ game: Game)
    func didEndTouchScreen(_ game: Game)
}

class Game: GKEntity, TouchHandler {
    
    private let entityManager: EntityManager
    private let scene: GameScene
    private let player: Player
    var delegate: GameDelegate?
    
    init(entityManager: EntityManager, scene: GameScene) {
        self.entityManager = entityManager
        self.scene = scene
        self.player = Player(entityManager: entityManager, scene: scene)
        super.init()
        
        load()
    }
    
    private func load() {
        // Background
        let background = Background(frame: scene.frame)
        entityManager.add(background)
        
        //PLayer
        player.delegate = self
        entityManager.add(self.player)
        
        //Rule
        let introductionRule = IntroductionLevelRule()
        self.delegate = introductionRule
        introductionRule.shouldStart(self, player: player)
    }
    
    func touchesBegan(_ point: CGPoint) {
        delegate?.didTouchScreen(self)
    }
    
    func touchesEnded(_ point: CGPoint) {
        delegate?.didEndTouchScreen(self)
    }
    
    func showHitTheCorrectTargetAnimation() {
        print("YAY!")
        let vNode = SKSpriteNode(imageNamed: "v")
        vNode.size = CGSize(width: 240, height: 220)
        vNode.setScale(0)
        vNode.position = CGPoint(x: 0, y: 400)
        vNode.zPosition = 200
        
        scene.addChild(vNode)
        
        let scaleAction = SKAction.scale(to: 0.7, duration: 0.2)
        let removeAction = SKAction.removeFromParent()
        let sequence = SKAction.sequence([scaleAction, scaleAction.reversed(), removeAction])
        vNode.run(sequence)
        
        let effect = SKAction.playSoundFileNamed("bell.flac", waitForCompletion: false)
        scene.run(effect)
    }
    
    func showHitTheWrongTargetAnimation() {
        print("NAY :(")
        let xNode = SKSpriteNode(imageNamed: "x")
        xNode.size = CGSize(width: 220, height: 220)
        xNode.setScale(0)
        xNode.position = CGPoint(x: 0, y: 400)
        xNode.zPosition = 200
        
        scene.addChild(xNode)
        
        let scaleAction = SKAction.scale(to: 0.7, duration: 0.2)
        let removeAction = SKAction.removeFromParent()
        let sequence = SKAction.sequence([scaleAction, scaleAction.reversed(), removeAction])
        xNode.run(sequence)
    }
    
    func createHoop(type: WasteType) -> Hoop {
        //Basket Hoop
        let hoop = Hoop(type: type)
        entityManager.add(hoop)
        hoop.delegate = self
        return hoop
    }
    
    func createHoop(at position: CGPoint, type: WasteType) -> Hoop {
        //Basket Hoop
        let hoop = Hoop(position: position, type: type)
        entityManager.add(hoop)
        hoop.delegate = self
        return hoop
    }
    
    func cleanScene() {
        for entity in entityManager.entities where !(entity is Game) && !(entity is Player) && !(entity is Background) {
            entityManager.remove(entity)
        }
    }
    
    func remove(_ entity: GKEntity) {
        entityManager.remove(entity)
    }
    
    func add(_ node: SKSpriteNode) {
        scene.addChild(node)
    }
    
    func run(_ action: SKAction) {
        scene.run(action)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

extension Game: PlayerDelegate, HoopDelegate {
    
    func didFallTheHoop(_ ball: Ball, correctBasket: Bool) {
        remove(ball)
        delegate?.didFallTheHoop(self, ball: ball, correctBasket: correctBasket)
    }
    
    func ballDidHitTheWall(_ ball: Ball) {
        delegate?.ballDidHitTheWall(self, ball: ball)
    }
    
    func didThrowBall(_ player: Player) {
        delegate?.didThrowBall(self, player: player)
    }
    
}
