//
//  Rule.swift
//  WWDC2019
//
//  Created by Giovanni Bruno on 24/03/19.
//  Copyright © 2019 Giovanni Bruno. All rights reserved.
//

import GameplayKit

protocol Rule: GameDelegate {}

class InfiniteLevelRule: Rule {
    
    private var currentBallIndex: Int = 0
    private var ballsType: [WasteType] = [.paper, .metal, .plastic, .glass].shuffled()
    private var dialogManager: DialogManager?
    private var started: Bool = false
    private var player: Player?
    
    func shouldStart(_ game: Game, player: Player) {
        game.cleanScene()
        self.dialogManager = DialogManager(level: 3, player: player, game: game)
        self.player = player
        _ = dialogManager?.nextDialog()
        createInitailHoops(game)
    }
    
    func ballDidHitTheWall(_ game: Game, ball: Ball) {
        let wait = SKAction.wait(forDuration: 3)
        let remove = SKAction.run {
            game.remove(ball)
        }
        let sequence = SKAction.sequence([wait, remove])
        ball.node?.run(sequence)
    }
    
    func didThrowBall(_ game: Game, player: Player) {
        let wait = SKAction.wait(forDuration: 0.7)
        let runBlock = SKAction.run { [weak self] in
            self?.repeatInteraction()
        }
        let sequence = SKAction.sequence([wait, runBlock])
        game.run(sequence)
    }
    
    func didFallTheHoop(_ game: Game, ball: Ball, correctBasket: Bool) {
        if correctBasket {
            game.showHitTheCorrectTargetAnimation()
            self.nextInteraction(game)
        } else {
            game.showHitTheWrongTargetAnimation()
        }
    }
    
    func didTouchScreen(_ game: Game) {
        if started {return}
        if let dialogManager = self.dialogManager {
            if !dialogManager.nextDialog() {
                self.startTheGame()
            }
        } else {
            self.startTheGame()
        }
    }
    
    func didEndTouchScreen(_ game: Game) {
        if let dialogManager = self.dialogManager, let player = self.player, !player.canPlay {
            if !dialogManager.nextDialog() {
                player.canPlay = true
            }
        }
    }
    
    private func nextInteraction(_ game: Game) {
        game.cleanScene()
        let newIndex = Int.random(0..<ballsType.count)
        player?.addNewBallForced(type: ballsType[newIndex])
        _ = game.createHoop(type: ballsType[newIndex])
        currentBallIndex = newIndex
    }
    
    private func createInitailHoops(_ game: Game) {
        _ = game.createHoop(at: .zero, type: ballsType[0])
    }
    
    private func startTheGame() {
        self.started = true
        self.player?.addNewBallForced(type: ballsType[currentBallIndex])
    }
    
    private func repeatInteraction() {
        guard let player = self.player else {return}
        if currentBallIndex < ballsType.count {
            player.addNewBall(type: ballsType[currentBallIndex])
        }
    }
    
}

class SecondLevelRule: Rule {
    
    private var currentBallIndex: Int = 0
    private var ballsType: [WasteType] = [.paper, .metal, .plastic, .glass].shuffled()
    private var dialogManager: DialogManager?
    private var started: Bool = false
    private var player: Player?
    
    func shouldStart(_ game: Game, player: Player) {
        game.cleanScene()
        self.dialogManager = DialogManager(level: 2, player: player, game: game)
        self.player = player
        player.canPlay = false
        _ = dialogManager?.nextDialog()
        createInitailHoops(game)
    }
    
    func ballDidHitTheWall(_ game: Game, ball: Ball) {
        let wait = SKAction.wait(forDuration: 3)
        let remove = SKAction.run {
            game.remove(ball)
        }
        let sequence = SKAction.sequence([wait, remove])
        ball.node?.run(sequence)
    }
    
    func didThrowBall(_ game: Game, player: Player) {
        let wait = SKAction.wait(forDuration: 0.7)
        let runBlock = SKAction.run { [weak self] in
            self?.repeatInteraction()
        }
        let sequence = SKAction.sequence([wait, runBlock])
        game.run(sequence)
    }
    
    func didFallTheHoop(_ game: Game, ball: Ball, correctBasket: Bool) {
        if correctBasket {
            game.showHitTheCorrectTargetAnimation()
            if self.currentBallIndex + 1 > self.ballsType.count, let player = self.player {
                self.nextRule(game, player: player)
            } else {
                self.nextInteraction(game)
            }
        } else {
            game.showHitTheWrongTargetAnimation()
        }
    }
    
    func didTouchScreen(_ game: Game) {
        if started {return}
        if let dialogManager = self.dialogManager {
            _ = dialogManager.nextDialog()
        }
    }
    
    func didEndTouchScreen(_ game: Game) {
        if let dialogManager = self.dialogManager, let player = self.player, !player.canPlay, !started {
            if !dialogManager.nextDialog() {
                let wait = SKAction.wait(forDuration: 0.7)
                let runBlock = SKAction.run { [weak self] in
                    self?.startTheGame()
                }
                let sequence = SKAction.sequence([wait, runBlock])
                game.run(sequence)
            }
        }
    }

    
    private func nextRule(_ game: Game, player: Player) {
        let infiniteLevelRule = InfiniteLevelRule()
        game.delegate = infiniteLevelRule
        infiniteLevelRule.shouldStart(game, player: player)
    }
    
    private func nextInteraction(_ game: Game) {
        let newIndex = currentBallIndex + 1
        if newIndex < ballsType.count {
            game.cleanScene()
            if newIndex == 1 {
                _ = game.createHoop(at: CGPoint(x: 450, y: -214), type: ballsType[newIndex])
                _ = game.createHoop(at: CGPoint(x: 130, y: -214), type: ballsType[2])
                _ = game.createHoop(at: CGPoint(x: -190, y: -214), type: ballsType[3])
            } else if newIndex == 2 {
                _ = game.createHoop(at: CGPoint(x: 270, y: 50), type: ballsType[newIndex])
                _ = game.createHoop(at: CGPoint(x: -200, y: 500), type: ballsType[1])
                _ = game.createHoop(at: CGPoint(x: 50, y: -370), type: ballsType[0])
            } else if newIndex == 3 {
                _ = game.createHoop(at: CGPoint(x: 145, y: 48), type: ballsType[newIndex])
                _ = game.createHoop(at: CGPoint(x: -165, y: 229), type: ballsType[0])
                _ = game.createHoop(at: CGPoint(x: 475, y: 229), type: ballsType[1])
            }
            player?.addNewBall(type: ballsType[newIndex])
            currentBallIndex = newIndex
        } else {
            guard let player = self.player else {return}
            nextRule(game, player: player)
        }
    }
    
    private func createInitailHoops(_ game: Game) {
        _ = game.createHoop(at: CGPoint(x: 182, y: 450), type: ballsType[0])
        _ = game.createHoop(at: CGPoint(x: -50, y: 50), type: ballsType[1])
        _ = game.createHoop(at: CGPoint(x: 450, y: 50), type: ballsType[2])
    }
    
    private func startTheGame() {
        self.started = true
        self.player?.addNewBall(type: ballsType[currentBallIndex])
    }
    
    private func repeatInteraction() {
        guard let player = self.player else {return}
        if currentBallIndex < ballsType.count {
            player.addNewBall(type: ballsType[currentBallIndex])
        }
    }
    
}

class FirsLevelRule: Rule {
    
    private var currentBallIndex: Int = 0
    private var ballsType: [WasteType] = [.paper, .metal, .plastic, .glass].shuffled()
    private var dialogManager: DialogManager?
    private var started: Bool = false
    private var player: Player?
    
    func shouldStart(_ game: Game, player: Player) {
        game.cleanScene()
        self.dialogManager = DialogManager(level: 1, player: player, game: game)
        self.player = player
        player.canPlay = false
        _ = dialogManager?.nextDialog()
        createInitailHoops(game)
    }
    
    func ballDidHitTheWall(_ game: Game, ball: Ball) {
        let wait = SKAction.wait(forDuration: 3)
        let remove = SKAction.run {
            game.remove(ball)
        }
        let sequence = SKAction.sequence([wait, remove])
        ball.node?.run(sequence)
    }
    
    func didThrowBall(_ game: Game, player: Player) {
        let wait = SKAction.wait(forDuration: 0.7)
        let runBlock = SKAction.run { [weak self] in
            self?.repeatInteraction()
        }
        let sequence = SKAction.sequence([wait, runBlock])
        game.run(sequence)
    }
    
    func didFallTheHoop(_ game: Game, ball: Ball, correctBasket: Bool) {
        if correctBasket {
            game.showHitTheCorrectTargetAnimation()
            if self.currentBallIndex + 1 > self.ballsType.count, let player = self.player {
                self.nextRule(game, player: player)
            } else {
                self.nextInteraction(game)
            }
        } else {
            game.showHitTheWrongTargetAnimation()
        }
    }
    
    func didTouchScreen(_ game: Game) {
        if started {return}
        if let dialogManager = self.dialogManager {
            _ = dialogManager.nextDialog()
        }
    }
    
    func didEndTouchScreen(_ game: Game) {
        if let dialogManager = self.dialogManager, let player = self.player, !player.canPlay, !started {
            if !dialogManager.nextDialog() {
                let wait = SKAction.wait(forDuration: 0.7)
                let runBlock = SKAction.run { [weak self] in
                    self?.startTheGame()
                }
                let sequence = SKAction.sequence([wait, runBlock])
                game.run(sequence)
            }
        }
    }
    
    private func nextRule(_ game: Game, player: Player) {
        let secondLevelRule = SecondLevelRule()
        game.delegate = secondLevelRule
        secondLevelRule.shouldStart(game, player: player)
    }
    
    private func nextInteraction(_ game: Game) {
        let newIndex = currentBallIndex + 1
        if newIndex < ballsType.count {
            game.cleanScene()
            if newIndex == 1 {
                _ = game.createHoop(at: CGPoint(x: 0, y: -200), type: ballsType[newIndex])
                _ = game.createHoop(at: CGPoint(x: 0, y: 500), type: ballsType[2])
            } else if newIndex == 2 {
                _ = game.createHoop(at: CGPoint(x: 300, y: 200), type: ballsType[newIndex])
                _ = game.createHoop(at: CGPoint(x: 200, y: -200), type: ballsType[1])
            } else if newIndex == 3 {
                _ = game.createHoop(at: CGPoint(x: 300, y: 500), type: ballsType[newIndex])
                _ = game.createHoop(at: CGPoint(x: 0, y: -200), type: ballsType[0])
            }
            player?.addNewBall(type: ballsType[newIndex])
            currentBallIndex = newIndex
        } else {
            guard let player = self.player else {return}
            nextRule(game, player: player)
        }
    }
    
    private func createInitailHoops(_ game: Game) {
        _ = game.createHoop(at: CGPoint(x: -50, y: -100), type: ballsType[0])
        _ = game.createHoop(at: CGPoint(x: 400, y: 400), type: ballsType[1])
    }
    
    private func startTheGame() {
        self.started = true
        self.player?.addNewBall(type: ballsType[currentBallIndex])
    }
    
    private func repeatInteraction() {
        guard let player = self.player else {return}
        if currentBallIndex < ballsType.count {
            player.addNewBall(type: ballsType[currentBallIndex])
        }
    }
    
}

class IntroductionLevelRule: Rule {
    
    private var ballsType: [WasteType] = [.paper, .metal, .plastic, .glass]
    private var currentBallIndex: Int = 0
    private var player: Player?
    private var currentHoop: Hoop?
    private var dialogManager: DialogManager?
    private var started: Bool = false
    
    func shouldStart(_ game: Game, player: Player) {
        game.cleanScene()
        self.dialogManager = DialogManager(level: 0, player: player, game: game)
        let hoop = game.createHoop(at: CGPoint(x: 0, y: -100), type: ballsType[0])
        self.currentHoop = hoop
        self.player = player
        player.canPlay = false
        _ = dialogManager?.nextDialog()
    }
    
    func ballDidHitTheWall(_ game: Game, ball: Ball) {
        let wait = SKAction.wait(forDuration: 3)
        let remove = SKAction.run {
            game.remove(ball)
        }
        let sequence = SKAction.sequence([wait, remove])
        ball.node?.run(sequence)
    }
    
    func didThrowBall(_ game: Game, player: Player) {
        let wait = SKAction.wait(forDuration: 0.7)
        let runBlock = SKAction.run { [weak self] in
            self?.repeatInteraction()
        }
        let sequence = SKAction.sequence([wait, runBlock])
        game.run(sequence)
    }
    
    func didTouchScreen(_ game: Game) {
        if started {return}
        if let dialogManager = self.dialogManager {
          _ = dialogManager.nextDialog()
        }
    }
    
    func didEndTouchScreen(_ game: Game) {
        if let dialogManager = self.dialogManager, let player = self.player, !player.canPlay, !started {
            if !dialogManager.nextDialog() {
                let wait = SKAction.wait(forDuration: 0.7)
                let runBlock = SKAction.run { [weak self] in
                    self?.startTheGame()
                }
                let sequence = SKAction.sequence([wait, runBlock])
                game.run(sequence)
            }
        }
    }

    func didFallTheHoop(_ game: Game, ball: Ball, correctBasket: Bool) {
        if correctBasket {
            game.showHitTheCorrectTargetAnimation()
            if self.currentBallIndex + 1 > self.ballsType.count, let player = self.player {
                self.nextRule(game, player: player)
            } else {
                self.nextInteraction(game)
            }
        } else {
            game.showHitTheWrongTargetAnimation()
        }
    }
    
    private func startTheGame() {
        self.started = true
        self.player?.addNewBall(type: ballsType[currentBallIndex])
    }
    
    private func nextRule(_ game: Game, player: Player) {
        let firstLevelRule = FirsLevelRule()
        game.delegate = firstLevelRule
        firstLevelRule.shouldStart(game, player: player)
    }
    
    private func nextInteraction(_ game: Game) {
        guard let hoop = self.currentHoop else {return}
        let newIndex = currentBallIndex + 1
        if newIndex < ballsType.count {
            game.remove(hoop)
            self.currentHoop = game.createHoop(at: CGPoint(x: 0, y: -100+CGFloat(newIndex)*50), type: ballsType[newIndex])
            self.player?.addNewBall(type: self.ballsType[newIndex])
            self.currentBallIndex = newIndex
        } else {
            guard let player = self.player else {return}
            nextRule(game, player: player)
        }
    }
    
    private func repeatInteraction() {
        guard let player = self.player else {return}
        if currentBallIndex < ballsType.count {
            player.addNewBall(type: ballsType[currentBallIndex])
        }
    }
    
    
}
