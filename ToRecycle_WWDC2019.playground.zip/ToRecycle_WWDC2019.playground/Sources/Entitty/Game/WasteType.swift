//
//  WasteType.swift
//  WWDC2019
//
//  Created by Giovanni Bruno on 24/03/19.
//  Copyright © 2019 Giovanni Bruno. All rights reserved.
//

import GameplayKit

enum WasteType: String {
    case paper, plastic, metal, glass
    
    func textureForHoop() -> SKTexture {
        return SKTexture(imageNamed: "\(self.rawValue)Hoop")
    }
    
    func textureForNet() -> SKTexture {
        return SKTexture(imageNamed: "\(self.rawValue)RecycleBinNet")
    }
    
    func textureForBall() -> SKTexture {
        return SKTexture(imageNamed: "\(self.rawValue)Waste")
    }
}
