//
//  Basket.swift
//  WWDC2019
//
//  Created by Giovanni Bruno on 23/03/19.
//  Copyright © 2019 Giovanni Bruno. All rights reserved.
//

import GameplayKit

protocol HoopDelegate {
    func didFallTheHoop(_ ball: Ball, correctBasket: Bool)
}

class Hoop: GKEntity, Contactable {
    
    private static let spawnAreaRect = CGRect(x: -260, y: -764, width: 900, height: 1500)
    
    public var delegate: HoopDelegate?
    public let type: WasteType
    
    convenience init(type: WasteType) {
        let randomX = CGFloat.random(in: Hoop.spawnAreaRect.minX...Hoop.spawnAreaRect.maxX)
        let randomY = CGFloat.random(in: Hoop.spawnAreaRect.minY...Hoop.spawnAreaRect.maxY)
        let randomPoint = CGPoint(x: randomX, y: randomY)
        self.init(position: randomPoint, type: type)
    }
    
    public init(position: CGPoint, type: WasteType) {
        self.type = type
        super.init()
        
        let node = SKSpriteNode(texture: type.textureForHoop())
        node.position = position
        var pbSize = node.size
        pbSize.height *= 0.5
        pbSize.width *= 0.8
        node.physicsBody = SKPhysicsBody(texture: node.texture!, size: pbSize)
        node.physicsBody?.isDynamic = false
        node.physicsBody?.categoryBitMask = Physics.hoopLine
        node.physicsBody?.contactTestBitMask = Physics.ball
        node.physicsBody?.collisionBitMask = Physics.none
        node.zPosition = 5
        
        let rimModifier: CGFloat = 0.2
        let leftRim = SKSpriteNode(imageNamed: "hoopPiece")
        leftRim.size = CGSize(width: node.size.width*rimModifier, height: node.size.height)
        leftRim.physicsBody = SKPhysicsBody(texture: leftRim.texture!, size: leftRim.size)
        leftRim.physicsBody?.isDynamic = false
        leftRim.physicsBody?.collisionBitMask = Physics.ball
        leftRim.isHidden = true
        
        node.addChild(leftRim)
        leftRim.position.x = -node.size.width/2 + leftRim.size.width/2
        leftRim.position.y = 0
        
        
        let rightRim = SKSpriteNode(imageNamed: "hoopPiece")
        rightRim.size = CGSize(width: node.size.width*rimModifier, height: node.size.height)
        rightRim.physicsBody = SKPhysicsBody(texture: rightRim.texture!, size: rightRim.size)
        rightRim.physicsBody?.isDynamic = false
        rightRim.physicsBody?.collisionBitMask = Physics.ball
        rightRim.isHidden = true
        
        node.addChild(rightRim)
        rightRim.position.x = node.size.width/2 - rightRim.size.width/2
        rightRim.position.y = 0
        
        let net = SKSpriteNode(texture: type.textureForNet())
        net.anchorPoint.y = 1
        net.position.y -= node.size.height/2
        
        let netPbNode = SKSpriteNode(imageNamed: "hoopPhysicsBody")
//        netPbNode.anchorPoint.y = 1
//        netPbNode.position = net.position
        node.addChild(netPbNode)
        netPbNode.position.y -= net.size.height/2
        
        netPbNode.physicsBody = SKPhysicsBody(texture: netPbNode.texture!, size: netPbNode.size)
        netPbNode.physicsBody?.isDynamic = false
        netPbNode.isHidden = true
        
        node.addChild(net)
        
        let sprite = Sprite(node: node)
        addComponent(sprite)
    }
    
    func didEnd(_ contact: SKPhysicsContact) {
        if let ballNode = ballNode(from: contact), isMovingDown(node: ballNode), let ball = ballNode.entity as? Ball {
            delegate?.didFallTheHoop(ball, correctBasket: isCorrectType(ball))
        }
    }
    
    private func isCorrectType(_ ball: Ball) -> Bool {
        return ball.type == self.type
    }
    
    private func ballNode(from contact: SKPhysicsContact) -> SKSpriteNode? {
        if contact.bodyA.node?.entity is Ball, let ballNode = contact.bodyA.node as? SKSpriteNode {
            return ballNode
        }
        
        if contact.bodyB.node?.entity is Ball, let ballNode = contact.bodyB.node as? SKSpriteNode {
            return ballNode
        }
        
        return nil
    }
    
    private func isMovingDown(node: SKSpriteNode) -> Bool {
        return node.physicsBody?.velocity.dy ?? 0 < 0.0
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
