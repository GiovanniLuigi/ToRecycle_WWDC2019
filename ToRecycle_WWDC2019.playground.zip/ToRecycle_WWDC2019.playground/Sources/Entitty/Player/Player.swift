//
//  Player.swift
//  WWDC2019
//
//  Created by Giovanni Bruno on 23/03/19.
//  Copyright © 2019 Giovanni Bruno. All rights reserved.
//

import GameplayKit

protocol PlayerDelegate {
    func ballDidHitTheWall(_ ball: Ball)
    func didThrowBall(_ player: Player)
}

class Player: GKEntity, TouchHandler, BallDelegate {
    
    private let entityManager: EntityManager
    private var ball: Ball?
    private let scene: GameScene
    var canPlay: Bool = false
    var delegate: PlayerDelegate?
    
    init(entityManager: EntityManager, scene: GameScene) {
        self.entityManager = entityManager
        self.scene = scene
        super.init()
        
        let node = SKSpriteNode(imageNamed: "player")
        node.position = CGPoint(x: -565, y: -720)
        
        let sprite = Sprite(node: node)
        addComponent(sprite)
    }
    
    private func throwBall(touchPoint: CGPoint) {
        ball?.throwBall(touchPoint: touchPoint)
        self.canPlay = false
        delegate?.didThrowBall(self)
        self.ball = nil
    }
    
    func touchesBegan(_ point: CGPoint) {
        if ball != nil && canPlay {
            showThrowPath(point)
        }
    }
    
    func touchesMoved(_ point: CGPoint) {
        if ball != nil && canPlay {
            showThrowPath(point)
        }
    }
    
    func touchesEnded(_ point: CGPoint) {
        if ball != nil && canPlay {
            cleanThrowPath()
            throwBall(touchPoint: point)
        }
    }
    
    func didHitTheWall(_ ball: Ball) {
        delegate?.ballDidHitTheWall(ball)
    }
    
    private func showThrowPath(_ point: CGPoint) {
        cleanThrowPath()
        if let ballNode = ball?.node {
            let midPoint = (ballNode.position + point)/2
            let distance = ballNode.position.distanceTo(midPoint)
            let direction = (midPoint - ballNode.position).normalized()
            for i in 0...Int(distance/65) {
                let newNode = SKSpriteNode(imageNamed: "circle")
                newNode.size = CGSize(width: 15, height: 15)
                newNode.position = ballNode.position + direction*CGFloat(i*50)
                newNode.name = "pathNode"
                if i != 0 {
                    scene.addChild(newNode)
                }
            }
        }
    }
    
    private func cleanThrowPath() {
        scene.enumerateChildNodes(withName: "pathNode") { (node, _) in
            node.removeFromParent()
        }
    }
    
    public func addNewBall(type: WasteType) {
//        if let myBall = self.ball {
//            if  myBall.type != type {
//                entityManager.remove(myBall)
//            } else {
//                return
//            }
//        }
//        let ball = Ball(type: type)
//        ball.delegate = self
//        self.ball = ball
//        entityManager.add(ball)
//        self.canPlay = true
        addNewBallForced(type: type)
    }
    
    public func addNewBallForced(type: WasteType) {
        if let myBall = self.ball {
            entityManager.remove(myBall)
        }
        let ball = Ball(type: type)
        ball.delegate = self
        self.ball = ball
        entityManager.add(ball)
        self.canPlay = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
