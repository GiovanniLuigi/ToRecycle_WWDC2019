//
//  GameScene.swift
//  WWDC2019
//
//  Created by Giovanni Bruno on 19/03/19.
//  Copyright © 2019 Giovanni Bruno. All rights reserved.
//

import SpriteKit
import GameplayKit

public class GameScene: SKScene, SKPhysicsContactDelegate {
    
    private var lastUpdateTime : TimeInterval = 0
    private var entityManager: EntityManager!
    
    
    override public func didMove(to view: SKView) {
        super.didMove(to: view)
        sceneSize = self.size
        
        self.lastUpdateTime = 0
        self.isUserInteractionEnabled = true
        self.physicsWorld.contactDelegate = self
        
        entityManager = EntityManager(scene: self)
        
        let game = Game(entityManager: entityManager, scene: self)
        entityManager.add(game)
        
        AudioManager.shared.playBackgroundMusic(filename: "Monplaisir_-_02_-_Garage.mp3")
    }
    
    // Contact
    
    public func didBegin(_ contact: SKPhysicsContact) {
        runIfFindContactable(contact) { (contactable) in
            contactable.didBegin(contact)
        }
    }
    
    public func didEnd(_ contact: SKPhysicsContact) {
        runIfFindContactable(contact) { (contactable) in
            contactable.didEnd(contact)
        }
    }
    
    private func runIfFindContactable(_ contact: SKPhysicsContact, completion: (_: Contactable) -> Void) {
        if let entity = contact.bodyA.node?.entity, let contactable = entity as? Contactable {
            completion(contactable)
        }
        if let entity = contact.bodyB.node?.entity, let contactable = entity as? Contactable {
            completion(contactable)
        }
    }
    
    
    // Touch
    
    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        entityManager.entities.forEach { (entity) in
            if let touchHandler = entity as? TouchHandler, let point = touches.first?.location(in: self) {
                touchHandler.touchesBegan(point)
            }
        }
    }
    
    override public func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        entityManager.entities.forEach { (entity) in
            if let touchHandler = entity as? TouchHandler, let point = touches.first?.location(in: self) {
                touchHandler.touchesEnded(point)
            }
        }
    }
    
    override public func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        entityManager.entities.forEach { (entity) in
            if let touchHandler = entity as? TouchHandler, let point = touches.first?.location(in: self) {
                touchHandler.touchesMoved(point)
            }
        }
    }
    
    
    override public func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
        
        // Initialize _lastUpdateTime if it has not already been
        if (self.lastUpdateTime == 0) {
            self.lastUpdateTime = currentTime
        }
        
        // Calculate time since last update
        let dt = currentTime - self.lastUpdateTime
        
        entityManager.update(dt)
        
        self.lastUpdateTime = currentTime
    }
}


public struct Physics {
    public static let none:       UInt32 = 0
    public static let ball:     UInt32 = 0b10
    public static let wall:       UInt32 = 0b100
    public static let hoopLine: UInt32 = 0b1000
}


protocol Contactable {
    func didBegin(_ contact: SKPhysicsContact)
    func didEnd(_ contact: SKPhysicsContact)
}

extension Contactable {
    func didBegin(_ contact: SKPhysicsContact) {}
    func didEnd(_ contact: SKPhysicsContact) {}
}

public var sceneSize: CGSize = .zero
