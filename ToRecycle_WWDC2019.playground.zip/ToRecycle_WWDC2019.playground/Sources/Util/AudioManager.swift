import Foundation
import AVFoundation


class AudioManager {
    
    static let shared = AudioManager()
    private var backgroundMusicPlayer: AVAudioPlayer!
    
    func playBackgroundMusic(filename: String, rate: Float = 1.0) {
        let resourceUrl = Bundle.main.url(forResource:
            filename, withExtension: nil)
        guard let url = resourceUrl else {
            print("Could not find file: \(filename)")
            return
        }
        do {
            try backgroundMusicPlayer =
                AVAudioPlayer(contentsOf: url)
            backgroundMusicPlayer.stop()
            backgroundMusicPlayer.numberOfLoops = -1
            backgroundMusicPlayer.rate = 1.0
            backgroundMusicPlayer.prepareToPlay()
            backgroundMusicPlayer.play()
        } catch {
            print("Could not create audio player!")
            return
        }
    }
    
    func stopBackGroundMusic() {
        if let player = self.backgroundMusicPlayer {
            player.stop()
        }
    }
    
}

